<h2>Panel de Administración</h2>
<p>Bienvenido, administrador.</p>

<h3>Opciones de Administración</h3>
<p><a href="index.php?controller=Usuario&action=logout">Cerrar Sesión</a></p>
