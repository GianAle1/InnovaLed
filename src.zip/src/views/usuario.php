<h2>Registro de Usuario</h2>
<form method="POST" action="index.php?controller=Usuario&action=registrar">
    Usuario: <input type="text" name="nombre_usuario" required><br>
    Contraseña: <input type="password" name="contrasena" required><br>
    <button type="submit">Registrar</button>
</form>
